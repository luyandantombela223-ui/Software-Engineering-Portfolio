// A program for Carslim.
// Luyanda Ntombela 
// NTMLUY004
// 19 August 2025 

import java.util.Scanner;

public class CarParkSim {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Initialize clock at 00:00
        Clock clock = new Clock(new Time("00:00"));
        Register register = new Register();

        System.out.println("Car Park Simulator");
        System.out.println("The current time is " + clock.examine().toString() + ".");
        System.out.println("Commands: advance {minutes}, arrive, depart, quit.");

        boolean running = true;

        while (running) {
            System.out.print(">");
            String input = sc.nextLine().trim();
            String[] parts = input.split("\\s+");

            switch (parts[0].toLowerCase()) {
                case "advance":
                    if (parts.length == 2) {
                        try {
                            int minutes = Integer.parseInt(parts[1]);
                            clock.advance(new Duration("minute", minutes));
                            System.out.println("The current time is " + clock.examine().toString() + ".");
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid number of minutes.");
                        }
                    } else {
                        System.out.println("Usage: advance {minutes}");
                    }
                    break;

                case "arrive":
                    String ticketID = UIDGenerator.makeUID();
                    Ticket ticket = new Ticket(clock.examine(), ticketID);
                    register.add(ticket);
                    System.out.println("Ticket issued: " + ticket.toString() + ".");
                    break;

                case "depart":
                    if (parts.length == 2) {
                        String id = parts[1];
                        if (register.contains(id)) {
                            Ticket t = register.retrieve(id);
                            Duration stay = t.age(clock.examine());
                            long hours = stay.intValue("hour");
                            long minutes = stay.intValue("minute") % 60;

                            System.out.println("Ticket details: " + t.toString() + ".");
                            System.out.println("Current time: " + clock.examine().toString() + ".");
                            if (hours > 0) {
                                System.out.println("Duration of stay: " + hours + " hour" + (hours > 1 ? "s" : "") + " " + minutes + " minutes.");
                            } else {
                                System.out.println("Duration of stay: " + minutes + " minutes.");
                            }
                        } else {
                            System.out.println("Invalid ticket ID.");
                        }
                    } else {
                        System.out.println("Usage: depart {ticketID}");
                    }
                    break;

                case "quit":
                    running = false;
                    System.out.println("Goodbye.");
                    break;

                default:
                    System.out.println("Unknown command.");
            }
        }

        sc.close();
    }
}
